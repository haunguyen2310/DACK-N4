package test;
import driver.driverFactory;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

import org.testng.annotations.Test;

import java.io.File;

@Test
public class bai6 {
    public static void test1() {
        int scc = 0;
        try {
            // Bước 1: Truy cập trang web
            WebDriver driver = driverFactory.getChromeDriver();
            driver.get("https://hades.vn/");

            // Bước 2: Đăng nhập vào ứng dụng
            WebElement NameElem = driver.findElement(By.xpath("//div[@class='col-md-3 display-flex-end nav-index-right']//a[@id='customer_login_link']"));
            NameElem.click();

            WebElement emailInput = driver.findElement(By.id("customer_email"));
            emailInput.sendKeys("lekimphutest4@gmail.com");

            WebElement passwordInput = driver.findElement(By.id("customer_password"));
            passwordInput.sendKeys("123456");

            WebElement loginButton = driver.findElement(By.xpath("//input[@value='Đăng nhập']"));
            loginButton.click();

            // Bước 3: Truy cập giỏ hàng và tiến hành thanh toán
            WebElement cartLink = driver.findElement(By.xpath("//div[contains(@class,'col-md-3 display-flex-end')]//span[@id='site-cart-handle']//a"));
            cartLink.click();

//            WebElement checkoutButton = driver.findElement(By.xpath("//a[@keylanguage='thanh_toan']"));
//            checkoutButton.click();
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // Wait for up to 10 seconds
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='lang linktocheckout button dark']")));
            element.click();


            // Bước 4: Nhập thông tin thanh toán và xác nhận đặt hàng
            WebElement phone = driver.findElement(By.id("billing_address_phone"));
            phone.sendKeys("123456789");


            WebElement address1 = driver.findElement(By.id("billing_address_address1"));
            address1.sendKeys("763/5/6");


//            WebElement element1 = driver.findElement(By.cssSelector("option[data-code='HC']"));
//            Actions actions = new Actions(driver);
//            actions.moveToElement(element1).click().build().perform();

            scc = (scc + 1);
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            String png = ("D:\\Selenium-baitap\\src\\test\\java\\testcase6\\image" + scc + ".png");
            FileUtils.copyFile(scrFile, new File(png));


//            WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("option[value='680']")));
//            element2.click();
//
//            WebElement element3 = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("option[data-code='27013']")));
//            element3.click();
            // Bước 5: Xác nhận đơn hàng đã được tạo thành công và lấy số serial
//            WebElement serialNumber = driver.findElement(By.xpath("//span[contains(@class, 'order-number')]"));
//            String orderSerial = serialNumber.getText();
//
//            System.out.println("Order created successfully. Serial number: " + orderSerial);


            // Đóng trình duyệt
//            driver.quit();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }
}