package test;

import driver.driverFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.time.Duration;

@Test
public class bai7{
    public static void Testcase07(){
        WebDriver driver = driverFactory.getChromeDriver();
        String image="";
        int scc = 0;
        try {
            //1. Go to https://hades.vn
            driver.get("https://hades.vn");

            //2. Click on My Account link
//            By ClickHereLinkText = By.linkText("ACCOUNT");
//            WebElement link = driver.findElement(ClickHereLinkText);
//            link.click();
//            By ClickHere = By.id("customer_login_link");
            WebElement clickAcc = driver.findElement(By.xpath("//div[@class='col-md-3 display-flex-end nav-index-right']//a[@id='customer_login_link']"));
            clickAcc.click();


            //3. Login in application using previously created credential
            WebElement loginEmail = driver.findElement(By.xpath("//input[@id='customer_email']"));
            loginEmail.click();
            loginEmail.sendKeys("lekimphutest3@gmail.com");

            WebElement loginPassword = driver.findElement(By.xpath("//input[@id='customer_password']"));
            loginPassword.click();
            loginPassword.sendKeys("123456");
            WebElement login = driver.findElement(By.xpath("//input[@value='Đăng nhập']"));
            login.click();

            //4. Click on 'My Orders'
            WebElement MyOrders = driver.findElement(By.xpath("//div[contains(@class,'col-md-3 display-flex-end')]//span[@id='site-cart-handle']//a"));
            MyOrders.click();

            //5. Click on 'View Order'
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // Wait for up to 10 seconds
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".lang.linktocart.button.dark")));
            element.click();

            //6. Verify the previously created order is displayed in 'RECENT ORDERS' table and status is Pending
            scc = (scc + 1);
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            String png = ("D:\\Selenium-baitap\\src\\test\\java\\testcase7\\image" + scc + ".png");
            FileUtils.copyFile(scrFile, new File(png));
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
