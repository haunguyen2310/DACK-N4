/*
Test Steps:
1. Step 1. Go to https://hades.vn/
2. Click on Shop All
3. In the list of all mobile , read the cost of PERSPECTIVE BLUR BROWN TEE
4. Click on Sony Xperia mobile
5. Read the Sony Xperia mobile from detail page. 6. Compare Product value in list and details page should be equal ($100).
*/
package test;
import driver.driverFactory;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

@Test
public class bai2 {

    public static void bai2(){
        WebDriver driver = driverFactory.getChromeDriver();
        String PriceList = "";
        String PriceDetail= "";
        try{
            //Step 1. Go to https://hades.vn/
            driver.get("https://hades.vn/");
            //Step 2. Click on Shop All
            WebElement ShopAllElem = driver.findElement(By.cssSelector("a[title='SHOP ALL']"));
            ShopAllElem.click();
            Thread.sleep(1500);
            //Step 3. In the list of all mobile , read the cost of Sony Xperia mobile (which is $100)
            WebElement Pricep = driver.findElement(By.cssSelector("a[title='PERSPECTIVE BLUR BROWN TEE']")).findElement(By.xpath("../..")).findElement(By.cssSelector(".pro-price"));
            PriceList = Pricep.getText();
            System.out.println("Giá tiền của PERSPECTIVE BLUR BROWN TEE ở trang Shop All: "+PriceList);
            //Step 4. Click on PERSPECTIVE BLUR BROWN TEE
            WebElement ProductDetail=driver.findElement(By.cssSelector(("a[title='PERSPECTIVE BLUR BROWN TEE']")));
            ProductDetail.click();
            //Step 5. Read the Sony Xperia mobile from detail page. 6. Compare Product value in list and details page should be equal ($100)
            WebElement Price2 = driver.findElement(By.cssSelector(".product-price .pro-price"));
            PriceDetail = Price2.getText();
            System.out.println("Giá tiền của PERSPECTIVE BLUR BROWN TEE ở trang chi tiết: "+PriceDetail);

            if(PriceList.equals(PriceDetail)){
                System.out.println("Giá tiền của PERSPECTIVE BLUR BROWN TEE ở 2 trang bằng nhau");
            }else{
                System.out.println("Giá tiền của PERSPECTIVE BLUR BROWN TEE ở 2 trang không bằng nhau");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
//        driver.close();
//        driver.quit();
    }
}
