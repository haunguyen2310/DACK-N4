package test;

//The next scenario is “Verify you can create account in E-commerce site and can share wishlist to other people using email”
//Detailed Test Case is below
/* Verify can create an account in e-Commerce site and can share wishlist to other poeple using email.
Test Steps:
1. Go to http://live.techpanda.org/
2. Click on my account link
3. Click Create an Account link and fill New User information except Email ID
4. Click Register
5. Verify Registration is done. Expected account registration done.
6. Go to TV menu
7. Add product in your wish list - use product - LG LCD
8. Click SHARE WISHLIST
9. In next page enter Email and a message and click SHARE WISHLIST
10.Check wishlist is shared. Expected wishlist shared successfully.
*/



import driver.driverFactory;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.File;
import java.time.Duration;

@Test

public class bai5{
    public static void testcase5() {

        // Init web-driver session
        WebDriver driver = driverFactory.getChromeDriver();
        int scc = 0;
        try {
            // 1. Go to http://live.techpanda.org/
            driver.get("https://hades.vn/");
            WebElement NameElem = driver.findElement(By.xpath("//div[contains(@class,'col-md-3 display-flex-end')]//a[@id='customer_login_link']"));
            NameElem.click();
            WebElement emailInput = driver.findElement(By.id("customer_email"));
            emailInput.sendKeys("lekimphutest4@gmail.com");

            WebElement passwordInput = driver.findElement(By.id("customer_password"));
            passwordInput.sendKeys("123456");

            WebElement loginButton = driver.findElement(By.xpath("//input[@value='Đăng nhập']"));
            loginButton.click();

            WebElement clickShop = driver.findElement(By.xpath("//a[@title='SHOP ALL']"));
            clickShop.click();

            WebElement ProductDetail=driver.findElement(By.cssSelector(("a[title='PERSPECTIVE BLUR BROWN TEE']")));
            ProductDetail.click();

            WebElement AddtoCart = driver.findElement(By.cssSelector("button[id='add-to-cart'] span[class='font-oswald lang']"));
            AddtoCart.click();

            scc = (scc + 1);
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            String png = ("D:\\Selenium-baitap\\src\\test\\java\\testcase5\\image" + scc + ".png");
            FileUtils.copyFile(scrFile, new File(png));

        }catch (Exception e){
            e.printStackTrace();
        }
        // Quit browser session
//        driver.close();
//        driver.quit();
    }
}
