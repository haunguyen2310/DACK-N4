/*
Test Steps:
1. Go to http://live.techpanda.org/
2. Click on my account link
3. Login in application using previously created credential
4. Click on 'REORDER' link , change QTY & click Update
5. Verify Grand Total is changed
6. Complete Billing & Shipping Information
7. Verify order is generated and note the order number
* */

package test;
import driver.driverFactory;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.File;
import java.time.Duration;

@Test
public class bai8 {
    public static void bai8(){
        int scc=0;
        WebDriver driver = driverFactory.getChromeDriver();
        try{
            //    Step 1. Go to https://hades.vn/
            driver.get("https://hades.vn");
            // Step 2. Click on my account link
            WebElement clickAcc = driver.findElement(By.xpath("//div[@class='col-md-3 display-flex-end nav-index-right']//a[@id='customer_login_link']"));
            clickAcc.click();
            // Step 3. Login in application using previously created credential
            WebElement loginEmail = driver.findElement(By.xpath("//input[@id='customer_email']"));
            loginEmail.click();
            loginEmail.sendKeys("lekimphutest4@gmail.com");

            WebElement loginPassword = driver.findElement(By.xpath("//input[@id='customer_password']"));
            loginPassword.click();
            loginPassword.sendKeys("123456");
            WebElement login = driver.findElement(By.xpath("//input[@value='Đăng nhập']"));
            login.click();
            //Step 4. Click on 'Giỏ hàng' link , change QTY
            WebElement clickCart=driver.findElement(By.xpath("//div[contains(@class,'col-md-3 display-flex-end')]//span[@id='site-cart-handle']//a"));
            clickCart.click();
            // xem giỏ hàng
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // Wait for up to 10 seconds
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='lang linktocart button dark']")));
            element.click();
//           Step 5. ChangeQTY
            WebElement changeQTY = driver.findElement(By.xpath("//button[normalize-space()='+']"));
            changeQTY.click();
            // Step 6. Verify
            scc = (scc + 1);
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            String png = ("D:\\Selenium-baitap\\src\\test\\java\\testcase8\\image" + scc + ".png");
            FileUtils.copyFile(scrFile, new File(png));
//
//            WebElement clickUpdate=driver.findElement(By.cssSelector("button[title='Update'] span span"));
//            clickUpdate.click();
//            //Step 5. Verify Grand Total is changed
//            scc = (scc + 1);
//            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//            String png = ("E:\\CD21CT3\\Selenium-baitap\\src\\test\\java\\bai8\\image" + scc + ".png");
//            FileUtils.copyFile(scrFile, new File(png));
//            //Step 6. Complete Billing & Shipping Information
//            WebElement clickPTC=driver.findElement(By.cssSelector("li[class='method-checkout-cart-methods-onepage-bottom'] button[title='Proceed to Checkout'] span span"));
//            clickPTC.click();
//            WebElement BillingI4Mation=driver.findElement(By.cssSelector("button[onclick='billing.save()'] span span"));
//            BillingI4Mation.click();
//            WebElement ShippingMethod=driver.findElement(By.cssSelector("button[onclick='shippingMethod.save()'] span span'] span span"));
//            ShippingMethod.click();
//            WebElement CheckMoney=driver.findElement(By.cssSelector("#p_method_checkmo"));
//            CheckMoney.click();
//            WebElement PayMent=driver.findElement(By.cssSelector("button[title='Place Order'] span span"));
//            PayMent.click();
//            //Step 7. Verify order is generated and note the order number
//            scc = (scc + 1);
//            File scrFile2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//            String png2 = ("E:\\CD21CT3\\Selenium-baitap\\src\\test\\java\\bai8\\image" + scc + ".png");
//            FileUtils.copyFile(scrFile2, new File(png2));
//            WebElement note=driver.findElement(By.cssSelector("a[href='http://live.techpanda.org/index.php/sales/order/view/order_id/18410/']"));
//            System.out.println("order number: "+note.getText());
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
