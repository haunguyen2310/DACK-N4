package test;
import driver.driverFactory;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;


import java.io.File;
import java.time.Duration;

//import static jdk.jpackage.internal.WixAppImageFragmentBuilder.Component.File;

@Test
public class bai1 {

    public static void testCase1(){
        int scc =0;

        WebDriver driver = driverFactory.getChromeDriver();
        try{
            //    Step 1. Go to https://hades.vn/
            driver.get("https://hades.vn/");
            //Step 2. Click on -> Shop all
            WebElement ShoppAllElem = driver.findElement(By.cssSelector("a[title='SHOP ALL']"));
            ShoppAllElem.click();
            //Step 3. In the list of Shop All , select MỚI NHẤT -> dropdown as BAN CHAY NHAT
            WebElement SortByElem=driver.findElement(By.cssSelector(".sort-by"));
            SortByElem.click();
            WebElement BANCHATNHATElem = driver.findElement(By.cssSelector("option[value='best-selling']"));
            BANCHATNHATElem.click();
            //Step 5. Verify all products are sorted by name

            scc = (scc + 1);
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            String png = ("D:\\Selenium-baitap\\src\\test\\java\\testcase1\\image" + scc + ".png");
            FileUtils.copyFile(scrFile, new File(png));
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

