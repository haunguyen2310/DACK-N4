/*
Test Steps:
1. Goto http://live.techpanda.org/
2. Click on �MOBILE� menu
3. In the list of all mobile , click on �ADD TO CART� for Sony Xperia mobile
4. Change �QTY� value to 1000 and click �UPDATE� button. Expected that an error is displayed
"The requested quantity for "Sony Xperia" is not available.
5. Verify the error message
6. Then click on �EMPTY CART� link in the footer of list of all mobiles. A message "SHOPPING CART IS EMPTY" is shown.
7. Verify cart is empty
 */
package test;
import driver.driverFactory;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.io.File;

@Test
public class bai3 {
    public static void bai3(){

        int scc=0;
        WebDriver driver = driverFactory.getChromeDriver();
        try {
            // Step 1. Goto https://hades.vn/
            driver.get("https://hades.vn/");
            //Step 2. Click on Shop All
            //Step 3: click product PERSPECTIVE BLUR BROWN TEE
            WebElement ShopAllElem = driver.findElement(By.cssSelector("a[title='SHOP ALL']"));
            ShopAllElem.click();
            Thread.sleep(1500);
            WebElement clickp = driver.findElement(By.cssSelector("a[title='PERSPECTIVE BLUR BROWN TEE']"));
            clickp.click();
            //Step 3. In the list of product detail , click on �ADD TO CART� for PERSPECTIVE BLUR BROWN TEE
            WebElement AddtoCart = driver.findElement(By.cssSelector("button[id='add-to-cart'] span[class='font-oswald lang']"));
            AddtoCart.click();
            Thread.sleep(1500);
            //Step 4: click viewCart
            WebElement ViewCart=driver.findElement(By.cssSelector(".lang.linktocart.button.dark"));
            ViewCart.click();
            Thread.sleep(1500);
            //Step 5: upate quantity for PERSPECTIVE BLUR BROWN TEE
            WebElement updateQuantity=driver.findElement(By.cssSelector("button[class='qtyplus qty-btn']"));
            int i;
            for(i=0;i<5;i++){
                updateQuantity.click();
            }
            Thread.sleep(1000);
            //Click tiếp tục mua hàng
            WebElement ttmh = driver.findElement(By.cssSelector(".continue"));
            ttmh.click();
            Thread.sleep(1500);
            WebElement Cart = driver.findElement(By.cssSelector("div[class='col-md-3 display-flex-end nav-index-right'] span[id='site-cart-handle'] a"));
            Cart.click();
            Thread.sleep(1000);
            scc = (scc + 1);
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            String png = ("D:\\Selenium-baitap\\src\\test\\java\\testcase3\\image" + scc + ".png");
            FileUtils.copyFile(scrFile, new File(png));
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
