/*
Test Steps:
1. Go to http://live.techpanda.org/
2. Click on �MOBILE� menu
3. In mobile products list , click on �Add To Compare� for 2 mobiles (Sony Xperia & Iphone)
4. Click on �COMPARE� button. A popup window opens
5. Verify the pop-up window and check that the products are reflected in it
Heading "COMPARE PRODUCTS" with selected products in it.
6. Close the Popup Windows
*/
package test;
import driver.driverFactory;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.io.File;

@Test
public class bai4 {
    public static void bai4(){
        // Init web-driver session
        WebDriver driver = driverFactory.getChromeDriver();
    int scc = 0;
        try {
            // 1. Go to http://live.techpanda.org/
            driver.get("https://hades.vn/#l=vi");

            WebElement NameElem = driver.findElement(By.xpath("//div[@class='col-md-3 display-flex-end nav-index-right']//a[@id='customer_register_link']"));
            NameElem.click();

            WebElement lastname = driver.findElement(By.xpath("//input[@id='last_name']"));
            lastname.sendKeys("Lê");
            WebElement firstname = driver.findElement(By.xpath("//input[@id='first_name']"));
            firstname.sendKeys("Phú");
            WebElement linkTextElem3 = driver.findElement(By.xpath("//label[@for='radio2']"));
            linkTextElem3.click();
            WebElement dateofbirth = driver.findElement(By.xpath("//input[@id='birthday']"));
            dateofbirth.sendKeys("3/1/2003");
            WebElement email = driver.findElement(By.xpath("//input[@id='email']"));
            email.sendKeys("lekimphutest4@gmail.com");
            WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
            password.sendKeys("123456");
            WebElement viewCart=driver.findElement(By.xpath("//input[@value='Đăng ký']"));
            viewCart.click();
            scc = (scc + 1);
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            String png = ("D:\\Selenium-baitap\\src\\test\\java\\testcase4\\image" + scc + ".png");
            FileUtils.copyFile(scrFile, new File(png));
        }catch(Exception e){
            e.printStackTrace();
        }

    }
}
